import React from 'react';
import { useNavigate } from 'react-router-dom';

function UserMenu({ Logout }) {
    const navigate = useNavigate();

    const submitHandler = e => {
        e.preventDefault();
        Logout();
    }

    return (
        <from onSubmit={submitHandler}>
            <h1>This is your menu</h1>
            <button type='submit' onClick={() => navigate('/login')}>Log out</button>
        </from>
        
        
    )

}

export default UserMenu;