import React from 'react';
import { useNavigate } from 'react-router-dom';

function ErrorPage( Logout ) {
    
    const navigate = useNavigate();

    const submitHandler = e => {
            e.preventDefault();
            Logout();
    }
    
    return (
        <from onSubmit={submitHandler}>
            <h1>You don't have enough permission</h1>
            <button type='submit' onClick={() => navigate('/login')}>Back to login page</button>
        </from>
    )

}

export default ErrorPage;