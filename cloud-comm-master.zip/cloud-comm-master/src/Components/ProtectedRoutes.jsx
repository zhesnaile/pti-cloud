import React from 'react';
import ErrorPage from '../Components/Common/ErrorPage';
import UserMenu from '../Components/Common/usermenu/UserMenu';


function ProtectedRoutes({ Auth, Logout }) {

    return (
        <div>
            {(Auth === false) ? (<ErrorPage Logout={Logout}/>) : <UserMenu Logout={Logout}/>}
        </div>
        
    )

}

export default ProtectedRoutes;