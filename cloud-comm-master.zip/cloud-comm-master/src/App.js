import React from 'react';
import {useState} from 'react';
import { Header } from './Components/Common'
import LoginForm from './Components/Common/loginform/LoginForm'
import RegisterForm from './Components/Common/registerform/RegisterForm'
import ErrorPage from './Components/Common/ErrorPage'
import ProtectedRoutes from './Components/ProtectedRoutes';
import './App.css';

import {
  Routes,
  Route,
  useNavigate,
} from 'react-router-dom';



function App() {

  const adminUser = {
    email: "admin@gmail.com",
    password: "123"
  }
  const navigate = useNavigate();
  

  const [user, setUser] = useState({email:"", password:""});
  const [error, setError] = useState(""); //catch if details are correct
  const [auth, setAuth] = useState(false); 


  const Login = details => {
    console.log(details);

    if(details.email === adminUser.email && details.password === adminUser.password){
      console.log("Logged in siuu");
      setUser({
        email: details.email,
        password: details.password
      })
      setAuth(true);
      navigate('/dashboard');
    }
    else{
      console.log("Credentials do not match");
      setError("Credentials do not match");
      setAuth(false);
    }
  }

  const Logout = () => {
    console.log("Logout");
    setUser({
      email: "",
      password: ""
    })
    setAuth(false);
    navigate('/login');
  }

  const Register = details => {
    console.log(details);
    if(details.email === "" || details.password === "" || details.password2 === ""){
      console.log("Fill all the blanks");
      setError("Fill all the blanks");
      setAuth(false);
    }
    else if(details.password === details.password2){
      console.log("User registered");
      setUser({
        email: details.email,
        password: details.password
      })
      setAuth(true);
      navigate('/dashboard');
    }
    else{
      console.log("Passwords do not match");
      setError("Passwords do not match");
      setAuth(false);
    }
  }

  return (
      <div className="App">
        <Header />
        <Routes>
          <Route path='/login' element={<LoginForm Login={Login} error={error}/>}/>
          <Route path='/register' element={<RegisterForm Register={Register} error={error}/>}/>
          <Route path='/dashboard' element={<ProtectedRoutes Auth={auth} Logout={Logout}/>} />
          <Route path='*' element={<ErrorPage Logout={Logout}/>} />
        </Routes>
      </div>
  );
}

export default App;
